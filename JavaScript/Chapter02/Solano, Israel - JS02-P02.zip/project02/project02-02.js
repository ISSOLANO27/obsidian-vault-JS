/*    JavaScript 7th Edition
      Chapter 2
      Project 02-02

      Application to test for completed form
      Author: Israel Solano
      Date: 02/22/2026

      Filename: project02-02.js
 */
 /*    JavaScript 7th Edition
      Chapter 2
      Project 02-02

      Application to test for completed form
      Author: Israel Solano
      Date: 02/22/2026

      Filename: project02-02.js
 */

// Function to verify form completion
function verifyForm() {

   // Get values from input fields
   let name = document.getElementById("name").value;
   let email = document.getElementById("email").value;
   let phone = document.getElementById("phone").value;

   // Check if all fields contain truthy (non-empty) values
   if (name && email && phone) {
      window.alert("Thank you!");
   } else {
      window.alert("Please fill in all fields");
   }
}

// Attach event listener to Submit button
document.getElementById("submit").addEventListener("click", verifyForm);
